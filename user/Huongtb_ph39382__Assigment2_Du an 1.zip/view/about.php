<div id="offcanvas-cart" class="offcanvas offcanvas-cart">
    <div class="inner">
        <div class="head">
            <span class="title">Cart</span>
            <button class="offcanvas-close">×</button>
        </div>
        <div class="body customScroll">
            <ul class="minicart-product-list">
                <li>
                    <a href="single-product.html" class="image"><img src="./user/public/assets/images/product-image/1.jpg" alt="Cart product Image"></a>
                    <div class="content">
                        <a href="single-product.html" class="title">Walnut Cutting Board</a>
                        <span class="quantity-price">1 x <span class="amount">$91.86</span></span>
                        <a href="#" class="remove">×</a>
                    </div>
                </li>
                <li>
                    <a href="single-product.html" class="image"><img src="./user/public/assets/images/product-image/2.jpg" alt="Cart product Image"></a>
                    <div class="content">
                        <a href="single-product.html" class="title">Lucky Wooden Elephant</a>
                        <span class="quantity-price">1 x <span class="amount">$453.28</span></span>
                        <a href="#" class="remove">×</a>
                    </div>
                </li>
                <li>
                    <a href="single-product.html" class="image"><img src="./user/public/assets/images/product-image/3.jpg" alt="Cart product Image"></a>
                    <div class="content">
                        <a href="single-product.html" class="title">Fish Cut Out Set</a>
                        <span class="quantity-price">1 x <span class="amount">$87.34</span></span>
                        <a href="#" class="remove">×</a>
                    </div>
                </li>
            </ul>
        </div>
        <div class="foot">
            <div class="sub-total">
                <table class="table">
                    <tbody>
                        <tr>
                            <td class="text-start">Sub-Total :</td>
                            <td class="text-end">$523.30</td>
                        </tr>
                        <tr>
                            <td class="text-start">Eco Tax (-2.00) :</td>
                            <td class="text-end">$4.52</td>
                        </tr>
                        <tr>
                            <td class="text-start">VAT (20%) :</td>
                            <td class="text-end">$104.66</td>
                        </tr>
                        <tr>
                            <td class="text-start">Total :</td>
                            <td class="text-end theme-color">$632.48</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="buttons">
                <a href="cart.html" class="btn btn-dark btn-hover-primary mb-30px">view cart</a>
                <a href="checkout.html" class="btn btn-outline-dark current-btn">checkout</a>
            </div>
            <p class="minicart-message">Free Shipping on All Orders Over $100!</p>
        </div>
    </div>
</div>
<!-- OffCanvas Cart End -->

<!-- OffCanvas Menu Start -->
<div id="offcanvas-mobile-menu" class="offcanvas offcanvas-mobile-menu">
    <button class="offcanvas-close"></button>
    <div class="inner customScroll">

        <div class="offcanvas-menu mb-20px">
            <ul>
                <li><a href="#"><span class="menu-text">Trang chủ</span></a>
                    <ul class="sub-menu">
                        <li><a href="index.html"><span class="menu-text">Home 1</span></a></li>
                        <li><a href="index-2.html"><span class="menu-text">Home 2</span></a></li>
                    </ul>
                </li>
                <li><a href="about.html">About Us</a></li>
                <li><a href="#"><span class="menu-text">Shop</span></a>
                    <ul class="sub-menu">
                        <li>
                            <a href="#"><span class="menu-text">Shop Page</span></a>
                            <ul class="sub-menu">
                                <li><a href="shop-3-column.html">Shop 3 Column</a></li>
                                <li><a href="shop-4-column.html">Shop 4 Column</a></li>
                                <li><a href="shop-left-sidebar.html">Shop Grid Left Sidebar</a></li>
                                <li><a href="shop-right-sidebar.html">Shop Grid Right Sidebar</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#"><span class="menu-text">product Details Page</span></a>
                            <ul class="sub-menu">
                                <li><a href="single-product.html">Product Single</a></li>
                                <li><a href="single-product-variable.html">Product Variable</a></li>
                                <li><a href="single-product-affiliate.html">Product Affiliate</a></li>
                                <li><a href="single-product-group.html">Product Group</a></li>
                                <li><a href="single-product-tabstyle-2.html">Product Tab 2</a></li>
                                <li><a href="single-product-tabstyle-3.html">Product Tab 3</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#"><span class="menu-text">Single Product Page</span></a>
                            <ul class="sub-menu">
                                <li><a href="single-product-slider.html">Product Slider</a></li>
                                <li><a href="single-product-gallery-left.html">Product Gallery Left</a>
                                </li>
                                <li><a href="single-product-gallery-right.html">Product Gallery Right</a>
                                </li>
                                <li><a href="single-product-sticky-left.html">Product Sticky Left</a></li>
                                <li><a href="single-product-sticky-right.html">Product Sticky Right</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="#"><span class="menu-text">Other Pages</span></a>
                            <ul class="sub-menu">
                                <li><a href="cart.html">Cart Page</a></li>
                                <li><a href="checkout.html">Checkout Page</a></li>
                                <li><a href="compare.html">Compare Page</a></li>
                                <li><a href="wishlist.html">Wishlist Page</a></li>
                                <li><a href="my-account.html">Account Page</a></li>
                                <li><a href="login.html">Login & Register Page</a></li>
                                <li><a href="empty-cart.html">Empty Cart Page</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="#"><span class="menu-text">Pages</span></a>
                    <ul class="sub-menu">
                        <li><a href="404.html">404 Page</a></li>
                        <li><a href="privacy-policy.html">Privacy Policy</a></li>
                        <li><a href="faq.html">Faq Page</a></li>
                        <li><a href="coming-soon.html">Coming Soon Page</a></li>
                    </ul>
                </li>
                <li><a href="#"><span class="menu-text">Blog</span></a>
                    <ul class="sub-menu">
                        <li><a href="#"><span class="menu-text">Blog Grid</span></a>
                            <ul class="sub-menu">
                                <li><a href="blog-grid-left-sidebar.html">Blog Grid Left Sidebar</a></li>
                                <li><a href="blog-grid-right-sidebar.html">Blog Grid Right Sidebar</a></li>
                            </ul>
                        </li>
                        <li><a href="#"><span class="menu-text">Blog List</span></a>
                            <ul class="sub-menu">
                                <li><a href="blog-list-left-sidebar.html">Blog List Left Sidebar</a></li>
                                <li><a href="blog-list-right-sidebar.html">Blog List Right Sidebar</a></li>
                            </ul>
                        </li>
                        <li><a href="#"><span class="menu-text">Blog Single</span></a>
                            <ul class="sub-menu">
                                <li><a href="blog-single-left-sidebar.html">Blog Single Left Sidebar</a></li>
                                <li><a href="blog-single-right-sidebar.html">Blog Single Right Sidbar</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a href="contact.html">Contact Us</a></li>
            </ul>
        </div>
        <!-- OffCanvas Menu End -->

        <!-- Language Currency start -->
        <div class="offcanvas-userpanel mt-8">
            <ul>
                <!-- Language Start -->
                <li class="offcanvas-userpanel__role">
                    <a href="#">English <i class="ion-ios-arrow-down"></i></a>
                    <ul class="user-sub-menu">
                        <li><a class="current" href="#">English</a></li>
                        <li><a href="#"> Italiano</a></li>
                        <li><a href="#"> Français</a></li>
                        <li><a href="#"> Filipino</a></li>
                    </ul>
                </li>
                <!-- Language End -->
                <!-- Currency Start -->
                <li class="offcanvas-userpanel__role">
                    <a href="#">USD $ <i class="ion-ios-arrow-down"></i></a>
                    <ul class="user-sub-menu">
                        <li><a class="current" href="#">USD $</a></li>
                        <li><a href="#">EUR €</a></li>
                        <li><a href="#">POUND £</a></li>
                        <li><a href="#">FRANC ₣</a></li>
                    </ul>
                </li>
                <!-- Currency End -->
            </ul>
        </div>
        <!-- Language Currency End -->
        <div class="offcanvas-social mt-auto">
            <ul>
                <li>
                    <a href="#"><i class="ion-social-facebook"></i></a>
                </li>
                <li>
                    <a href="#"><i class="ion-social-twitter"></i></a>
                </li>
                <li>
                    <a href="#"><i class="ion-social-google"></i></a>
                </li>
                <li>
                    <a href="#"><i class="ion-social-youtube"></i></a>
                </li>
                <li>
                    <a href="#"><i class="ion-social-instagram"></i></a>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- OffCanvas Menu End -->


<div class="offcanvas-overlay"></div>
<!-- breadcrumb-area start -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="row breadcrumb_box  align-items-center">
                    <div class="col-lg-6 col-md-6 col-sm-12 text-center text-md-start">
                        <h2 class="breadcrumb-title">Giới thiệu</h2>
                    </div>
                    <div class="col-lg-6  col-md-6 col-sm-12">
                        <!-- breadcrumb-list start -->
                        <ul class="breadcrumb-list text-center text-md-end">
                            <li><a href="?act=home">Trang chủ</a></li>
                            <li class="active">/giới thiệu</li>
                        </ul>
                        <!-- breadcrumb-list end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- breadcrumb-area end -->

<!-- About Us Area Start -->
<section class="about-area pb-100px pt-100px">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="about-left-image mb-md-30px mb-lm-30px" data-aos="fade-up">
                    <img src="./user/public/assets/images/about-image/1.jpg" alt="" class="img-responsive w-100" />
                </div>
            </div>
            <div class="col-lg-6">
                <div class="about-content">
                    <div class="about-title" data-aos="fade-up">
                        <h2>Chào mừng bạn đến với LTH Furniture </h2>
                    </div>
                    <p class="mb-30px" data-aos="fade-up" data-aos-delay="200">
                        Nơi tinh tế hóa không gian sống của bạn! Chúng tôi tự hào là địa chỉ đáng tin cậy cho mọi người có nhu cầu tìm kiếm nội thất chất lượng và đẳng cấp. Với một sứ mệnh làm đẹp và làm mới không gian sống, LTH Furniture mang đến cho khách hàng sự trải nghiệm mua sắm trực tuyến độc đáo và tuyệt vời.
                    </p>
                    <p data-aos="fade-up" data-aos-delay="300">
                        Tại LTH Furniture, chúng tôi chú trọng vào việc cung cấp những sản phẩm nội thất cao cấp với thiết kế đẹp mắt, chất lượng vững chắc và giá trị đích thực. Chúng tôi tự tin rằng, từ bàn ghế, kệ sách, đèn trang trí đến bàn làm việc, mọi sản phẩm đều được lựa chọn kỹ lưỡng để đáp ứng mọi nhu cầu và gu thẩm mỹ của khách hàng.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- About Us Area End -->
<!-- Start Slill Progress -->
<div class="progressbar-section">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="content" data-aos="fade-up" data-aos-delay="0">
                    <h4 class="title">Sự Hài Hòa Giữa Chức Năng và Sự Hoàn Hảo</h4>
                    <p class="title-desc">
                        Trong thời đại ngày nay, không ai có thể đánh giá thấp tầm quan trọng của thiết kế, nghệ thuật tạo ra hình ảnh nổi bật để di chuyển và thu hút khán giả của bạn. Và khi thế giới trở nên ngày càng số hóa với mỗi giây trôi qua, vai trò của thiết kế đồ họa đã được đẩy lên đỉnh cao.</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="custom-progress m-t-40">
                    <div class="skill-progressbar" data-aos="fade-up" data-aos-delay="0">
                        <h6 class="font--semi-bold m-b-15">UI/UX</h6>
                        <div class="line-progressbar" data-percentage="75" data-progress-color="#ff7004"></div>
                    </div>
                    <div class="skill-progressbar" data-aos="fade-up" data-aos-delay="200">
                        <h6 class="font--semi-bold m-b-15">Ý tưởng</h6>
                        <div class="line-progressbar" data-percentage="86" data-progress-color="#ff7004"></div>
                    </div>
                    <div class="skill-progressbar" data-aos="fade-up" data-aos-delay="400">
                        <h6 class="font--semi-bold m-b-15">Thiết kế</h6>
                        <div class="line-progressbar" data-percentage="97" data-progress-color="#ff7004"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End Slill Progress -->
<div class="banner-preduct-wrapper pt-100px pb-100px">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 pr-0">
                <div class="banner-product-image">
                    <a class="venobox " href="./user/public/assets/images/banner/8.jpg" data-gall="myGallery">
                        <img src="./user/public/assets/images/banner/8.jpg" class="img-fluid w-100" alt="Banner images">
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-4">
                <div class="banner-product-image mt-lm-15px">
                    <a class="venobox " href="./user/public/assets/images/banner/9.jpg" data-gall="myGallery">
                        <img src="./user/public/assets/images/banner/9.jpg" class="img-fluid w-100" alt="Banner images">
                    </a>
                </div>
                <div class="banner-product-image mt-3">
                    <a class="venobox " href="./user/public/assets/images/banner/10.jpg" data-gall="myGallery">
                        <img src="./user/public/assets/images/banner/10.jpg" class="img-fluid w-100" alt="Banner images">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!--  Start  Team Section    -->
<div class="team-section">
    <!-- Start Section Content Text Area -->
    <div class="section-title-wrapper" data-aos="fade-up" data-aos-delay="0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-title text-center">
                        <h2 class="title">Thành viên của chúng tôi</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Section Content Text Area -->
    <div class="team-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-25px">
                    <div class="team-single" data-aos="fade-up" data-aos-delay="0">
                        <div class="team-img">
                            <img class="img-fluid" src="upload/luan.png" alt="">
                        </div>
                        <div class="team-content">
                            <h6 class="team-name font--bold mt-5">Luân Nguyễn</h6>
                            <span class="team-title">Web Designer</span>
                            <ul class="team-social pos-absolute">
                                <li><a href="#"><i class="ion-social-facebook"></i></a></li>
                                <li><a href="#"><i class="ion-social-twitter"></i></a></li>
                                <li><a href="#"><i class="ion-social-instagram"></i></a></li>
                                <li><a href="#"><i class="ion-social-linkedin"></i></a></li>
                                <li><a href="#"><i class="ion-social-rss"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 mb-25px">
                    <div class="team-single" data-aos="fade-up" data-aos-delay="600">
                        <div class="team-img">
                            <img class="img-fluid" src="upload/trung.png" alt="">
                        </div>
                        <div class="team-content">
                            <h6 class="team-name font--bold mt-5">Quốc Trung</h6>
                            <span class="team-title">Web Designer</span>
                            <ul class="team-social pos-absolute">
                                <li><a href="#"><i class="ion-social-facebook"></i></a></li>
                                <li><a href="#"><i class="ion-social-twitter"></i></a></li>
                                <li><a href="#"><i class="ion-social-instagram"></i></a></li>
                                <li><a href="#"><i class="ion-social-linkedin"></i></a></li>
                                <li><a href="#"><i class="ion-social-rss"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6 mb-25px">
                    <div class="team-single" data-aos="fade-up" data-aos-delay="200">
                        <div class="team-img">
                            <img class="img-fluid" src="upload/huong.png" alt="">
                        </div>
                        <div class="team-content">
                            <h6 class="team-name font--bold mt-5">Trịnh Hướng</h6>
                            <span class="team-title">Web Designer</span>
                            <ul class="team-social pos-absolute">
                                <li><a href="#"><i class="ion-social-facebook"></i></a></li>
                                <li><a href="#"><i class="ion-social-twitter"></i></a></li>
                                <li><a href="#"><i class="ion-social-instagram"></i></a></li>
                                <li><a href="#"><i class="ion-social-linkedin"></i></a></li>
                                <li><a href="#"><i class="ion-social-rss"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
<!--   End  Team Section   -->